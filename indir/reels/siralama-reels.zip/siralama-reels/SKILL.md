---
name: siralama-reels
description: Konuşurken S-A-B-C sıralama tablosu kurar; seçenekler söylendiği anda tablodaki yerine oturur. Remotion kullanır.
---

# Sıralama Reels

"En iyi 5 ..." ya da "... sıralıyorum" videoları için ekranın üst yarısında S-A-B-C (gerekirse D) sıralama tablosu kurar.

## Ne yapar
1. Kullanıcıdan seçenek listesini ve her birinin harfini al. Verilmediyse dökümden çıkar ve onaylat.
2. Tablo: üst yarıda, satır başlarında renkli harf kutuları (S kırmızı, A turuncu, B sarı, C yeşil, D mavi; marka renkleriyle çakışırsa tonları yumuşat). Tablo arka planı koyu, yarı saydam.
3. Her seçenek dökümde adının geçtiği kelimede, küçük bir rozet olarak konuşanın yanında belirir ve 12 karede tablodaki satırına uçar (`spring`).
4. Rozet: logo ya da baş harf + ad. Kullanıcı logo dosyası verdiyse kullan, telif/marka hakkına dikkat et.
5. Son saniyede tablonun tamamı 1 sn sabit kalsın ki izleyici ekran görüntüsü alabilsin.
6. Altyazı ve kapanış `isletme-reels` kurallarıyla aynı.

## Not
Sıralama tartışma çıkarır; videonun sonunda "Sen olsan neyi değiştirirdin? Yoruma yaz." gibi bir soru öner.

## Ortak teknik kurallar

**Altyapı:** Remotion projesi (React ile video). Proje yoksa kullanıcıya `npx create-video@latest --yes --blank reels` ile oluşturmayı ve `npx remotion skills add` ile Remotion'ın resmi skill'lerini kurmayı öner. Remotion API'sinde emin olmadığın her şey için Remotion'ın resmi skill'ine ya da belgelerine bak; tahminle API yazma.

**Video ayarları:** 1080x1920, 30 fps, dikey. Ham videoyu `public/` klasörüne koy, `<OffthreadVideo src={staticFile(...)}/>` ile kullan. Süreyi ham videonun süresinden hesapla (`parseMedia` ya da ffprobe).

**Marka:** Proje kökünde `marka.md` varsa oku (renkler, yazı tipi, logo dosyası, hesap adı, kapanış cümlesi). Yoksa işe başlamadan kullanıcıya bu 5 bilgiyi bir kerede sor ve cevapları `marka.md` olarak kaydet. Sonraki videolarda tekrar sorma.

**Döküm:** Altyazı ve zamanlama için konuşmayı kelime kelime zamanlı yazıya dök (ör. `@remotion/install-whisper-cpp` ile whisper.cpp, dil: Türkçe). Dökümü `public/dokum.json` olarak kaydet. Türkçe karakterleri (ç, ğ, ı, İ, ö, ş, ü) kontrol et; büyük harfe çevirirken `toLocaleUpperCase('tr-TR')` kullan.

**Güvenli alan (Instagram Reels):** Yazı ve kartları kenarlardan en az 60 px içeride tut; üstte 220 px, altta 420 px, sağda 140 px boşluk bırak. Hiçbir yazı ekrandan taşmamalı; uzun başlıkta yazı boyutunu küçült ya da satıra böl.

**Animasyon:** `spring()` ve `interpolate()` kullan, `extrapolateRight: 'clamp'` ekle. Giriş 8-12 kare, çıkış 6-8 kare. Aynı anda en fazla bir büyük animasyon.

**Ses:** Müzik dosyası kullanıcıdan gelmeli ya da kullanım hakkı olan bir kütüphaneden seçilmeli. Konuşma varken müzik seviyesi 0.08-0.15.

**Akış:**
1. Planı 5-8 maddeyle yaz (hangi saniyede ne olacak), kullanıcı onaylasın.
2. Kodu yaz, `npx remotion studio` ile önizleme öner.
3. Düzeltmeleri düz Türkçe al, uygula.
4. `npx remotion render <id> out/<ad>.mp4` ile dışa aktar.
5. İyi çalışan ayarları `marka.md`ye not et.

**Kontrol:** Teslimden önce 3-4 kareyi `npx remotion still` ile çıkarıp bak: taşan yazı, yanlış Türkçe karakter, altyazı-efekt çakışması olmamalı. İsim ve rakamları kullanıcıya teyit ettir.

---
Hazırlayan: Move to Social — movetosocial.com.tr · Instagram: @movetosocialtr
