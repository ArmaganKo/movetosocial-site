---
name: effects
description: Reels'e 10 efekt ekler: arkadan geçen yazı, yörünge kartlar, dergi kapağı, donan kare, cam kartlar, spot, sayan rakam, liste, sıralama, düğmeler.
---

# Effects — Reels için 10 efekt

`/effects <efekt-adı>` ile çağrılır. Efekt adı verilmezse 10 efekti listele ve hangisinin hangi saniyeye uygun olduğunu dökümden öner.

Her efekt, dökümdeki tetik kelimeyle başlar (kullanıcı belirtmediyse sor). Efekt sırasında altyazı görünür kalmalı.

## 1. text-behind — Arkadan geçen yazı
Büyük başlık kişinin **arkasında** durur. Kişiyi arka plandan ayırmak için her kareye segmentasyon maskesi çıkar (ör. Python + `rembg` ya da MediaPipe Selfie Segmentation; çıktıyı saydam PNG dizisi olarak `public/maske/` içine kaydet). Katman sırası: arka plan video → yazı → maskelenmiş kişi. Yazı kalın, ekran genişliğinin %85'i, harf harf ya da soldan sağa açılır. Arka plan karışıksa kullanıcıyı kenar titremesi konusunda uyar.

## 2. orbit — Yörüngede dönen kartlar
4-8 görsel kart, kişinin başının etrafında elips yörüngede döner. Arkadan geçen kartlar küçülür ve hafif bulanıklaşır, öndekiler büyür (z-sıralaması `Math.sin(açı)` ile). Bir tur 3-4 sn.

## 3. match-cut — Dergi kapağı geçişi
Görüntü bir karede dergi/gazete kapağı tasarımına geçer: üstte dergi adı (kurgusal, gerçek dergi markası kullanma), ortada kişi, başlıkta vurgulu kelime marka renginde. 1,5-2 sn sonra videoya geri dön.

## 4. freeze-frame — Donan kare
Video bir karede durur, kare beyaz çerçeveli polaroide dönüşür, hafif döner (−4°), arka plan bulanıklaşır. Altına el yazısı fontla kısa not ("tam bu an!") ve çizilen ok. 1,5 sn sonra devam.

## 5. glass-widgets — Cam bilgi kartları
Köşelerde yarı saydam kartlar: küçük başlık + büyük değer + mini grafik ya da ilerleme halkası. Değerler sayarak artar. **Rakam uydurma**; kullanıcıdan al.

## 6. spotlight — Spot ışığı
Ekran karanlığa iner, kişinin üstünden yumuşak bir ışık konisi düşer (radyal gradyan + hafif toz parçacıkları). 2-3 sn, sonra normale döner.

## 7. numbers — Sayan rakamlar
Büyük rakam sıfırdan hedef değere sayar (ease-out, 1-1,5 sn), altında italik birim ("izlenme"). Türkçe binlik ayırıcı: 400.000.

## 8. todo — Tiklenen liste
Köşede başlıklı küçük liste; konuşmada her madde geçtiğinde işaretlenir ve üstü çizilir. En fazla 5 madde.

## 9. tier-list — Sıralama tablosu
Üstte S-A-B-C tablosu; adı geçen seçenek rozet olarak belirip satırına uçar. Gerçek marka logoları kullanılacaksa kullanıcıyı marka hakları konusunda uyar.

## 10. apple-toggles — Açılan düğmeler
Telefon ayarlarını andıran yarı saydam panel; satırlar (ikon + metin + düğme) sırayla açılır, düğme yeşile döner. Kapanışlar için uygun.

## Doz kuralı
30 sn'lik videoda en fazla 2-3 efekt. Efekt söyleneni desteklemeli. Aynı efekti üst üste kullanma.

## Ortak teknik kurallar

**Altyapı:** Remotion projesi (React ile video). Proje yoksa kullanıcıya `npx create-video@latest --yes --blank reels` ile oluşturmayı ve `npx remotion skills add` ile Remotion'ın resmi skill'lerini kurmayı öner. Remotion API'sinde emin olmadığın her şey için Remotion'ın resmi skill'ine ya da belgelerine bak; tahminle API yazma.

**Video ayarları:** 1080x1920, 30 fps, dikey. Ham videoyu `public/` klasörüne koy, `<OffthreadVideo src={staticFile(...)}/>` ile kullan. Süreyi ham videonun süresinden hesapla (`parseMedia` ya da ffprobe).

**Marka:** Proje kökünde `marka.md` varsa oku (renkler, yazı tipi, logo dosyası, hesap adı, kapanış cümlesi). Yoksa işe başlamadan kullanıcıya bu 5 bilgiyi bir kerede sor ve cevapları `marka.md` olarak kaydet. Sonraki videolarda tekrar sorma.

**Döküm:** Altyazı ve zamanlama için konuşmayı kelime kelime zamanlı yazıya dök (ör. `@remotion/install-whisper-cpp` ile whisper.cpp, dil: Türkçe). Dökümü `public/dokum.json` olarak kaydet. Türkçe karakterleri (ç, ğ, ı, İ, ö, ş, ü) kontrol et; büyük harfe çevirirken `toLocaleUpperCase('tr-TR')` kullan.

**Güvenli alan (Instagram Reels):** Yazı ve kartları kenarlardan en az 60 px içeride tut; üstte 220 px, altta 420 px, sağda 140 px boşluk bırak. Hiçbir yazı ekrandan taşmamalı; uzun başlıkta yazı boyutunu küçült ya da satıra böl.

**Animasyon:** `spring()` ve `interpolate()` kullan, `extrapolateRight: 'clamp'` ekle. Giriş 8-12 kare, çıkış 6-8 kare. Aynı anda en fazla bir büyük animasyon.

**Ses:** Müzik dosyası kullanıcıdan gelmeli ya da kullanım hakkı olan bir kütüphaneden seçilmeli. Konuşma varken müzik seviyesi 0.08-0.15.

**Akış:**
1. Planı 5-8 maddeyle yaz (hangi saniyede ne olacak), kullanıcı onaylasın.
2. Kodu yaz, `npx remotion studio` ile önizleme öner.
3. Düzeltmeleri düz Türkçe al, uygula.
4. `npx remotion render <id> out/<ad>.mp4` ile dışa aktar.
5. İyi çalışan ayarları `marka.md`ye not et.

**Kontrol:** Teslimden önce 3-4 kareyi `npx remotion still` ile çıkarıp bak: taşan yazı, yanlış Türkçe karakter, altyazı-efekt çakışması olmamalı. İsim ve rakamları kullanıcıya teyit ettir.

---
Hazırlayan: Move to Social — movetosocial.com.tr · Instagram: @movetosocialtr
