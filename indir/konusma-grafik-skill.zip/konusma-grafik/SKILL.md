---
name: konusma-grafik
description: Konuşmalı videoya komutla grafik ekler: profil kartı, harita ve rota, site önizlemesi, ekranı bölüp liste, renk ayarı, müzik. Remotion kullanır.
---

# Konuşma Grafik

Kameraya konuşulan videoya, üstte yazılan komutlarla motion grafik ekler. Videonun üstünde koyu bir komut çubuğu ("Claude'a yaz...") durur; her komut harf harf yazılır, gönderilir ve hemen ekranda gerçekleşir.

## Yerleşim
- Arka plan: açık krem, ortada yuvarlak köşeli video kartı (kurgulu), altında ikinci kart (ham video, "Ham video" etiketi).
- Komut çubuğu kartın üstünde; komut metni dökümden ya da kullanıcının listesinden gelir.

## 6 grafik
1. **İsim + profil kartı:** Zarif serif yazıyla isim, yanında Instagram profil kartı (fotoğraf, gönderi/takipçi sayıları kullanıcıdan, "Takip et" butonu).
2. **Harita + rota:** Noktalı dünya haritası arka planı, iki şehir arasında yay çizen uçuş çizgisi, uçak ikonu çizgi boyunca ilerler, şehir adları belirir. Harita için açık lisanslı bir dünya GeoJSON'u kullan, noktalara dönüştür; Mapbox gibi ücretli servis kullanılacaksa kullanıcıya sor.
3. **Site önizlemesi:** Kullanıcının verdiği ekran görüntüleri kartlar hâlinde yanında açılır ve yelpaze gibi kayar.
4. **Ekranı ikiye böl + liste:** Video sola kayar, sağ yarıda başlık (italik serif) ve numaralı liste; maddeler konuşmada geçtikçe tek tek gelir.
5. **Renk ayarı:** Küçük ayar paneli (sıcaklık, doygunluk kaydırıcıları) açılır, kaydırıcı hareket ederken görüntünün tonu değişir. "Benim tonlarım" denirse marka.md'deki tona geç.
6. **Müzik + ses efekti:** Müzik kartı ("Eski parça" → "Yeni parça") geçer; geçişlere kısa whoosh/pop efektleri eklenir. Ses dosyalarının kullanım hakkı kullanıcıda olmalı.

## Ek: "Arkamda 20 video göster"
Kullanıcının eski videolarından kareler ızgarada çoğalarak arkada belirir, köşede sayaç (08 → 20).

## Kapanış
Ürün/hizmet adı üstte sabitlenir, akış rozetleri ("Ham video → Altyazı → Kartlar → Kapak"), sonda yorum CTA'sı ve hesap adı.

## Ortak teknik kurallar

**Altyapı:** Remotion projesi (React ile video). Proje yoksa kullanıcıya `npx create-video@latest --yes --blank reels` ile oluşturmayı ve `npx remotion skills add` ile Remotion'ın resmi skill'lerini kurmayı öner. Remotion API'sinde emin olmadığın her şey için Remotion'ın resmi skill'ine ya da belgelerine bak; tahminle API yazma.

**Video ayarları:** 1080x1920, 30 fps, dikey. Ham videoyu `public/` klasörüne koy, `<OffthreadVideo src={staticFile(...)}/>` ile kullan. Süreyi ham videonun süresinden hesapla (`parseMedia` ya da ffprobe).

**Marka:** Proje kökünde `marka.md` varsa oku (renkler, yazı tipi, logo dosyası, hesap adı, kapanış cümlesi). Yoksa işe başlamadan kullanıcıya bu 5 bilgiyi bir kerede sor ve cevapları `marka.md` olarak kaydet. Sonraki videolarda tekrar sorma.

**Döküm:** Altyazı ve zamanlama için konuşmayı kelime kelime zamanlı yazıya dök (ör. `@remotion/install-whisper-cpp` ile whisper.cpp, dil: Türkçe). Dökümü `public/dokum.json` olarak kaydet. Türkçe karakterleri (ç, ğ, ı, İ, ö, ş, ü) kontrol et; büyük harfe çevirirken `toLocaleUpperCase('tr-TR')` kullan.

**Güvenli alan (Instagram Reels):** Yazı ve kartları kenarlardan en az 60 px içeride tut; üstte 220 px, altta 420 px, sağda 140 px boşluk bırak. Hiçbir yazı ekrandan taşmamalı; uzun başlıkta yazı boyutunu küçült ya da satıra böl.

**Animasyon:** `spring()` ve `interpolate()` kullan, `extrapolateRight: 'clamp'` ekle. Giriş 8-12 kare, çıkış 6-8 kare. Aynı anda en fazla bir büyük animasyon.

**Ses:** Müzik dosyası kullanıcıdan gelmeli ya da kullanım hakkı olan bir kütüphaneden seçilmeli. Konuşma varken müzik seviyesi 0.08-0.15.

**Akış:**
1. Planı 5-8 maddeyle yaz (hangi saniyede ne olacak), kullanıcı onaylasın.
2. Kodu yaz, `npx remotion studio` ile önizleme öner.
3. Düzeltmeleri düz Türkçe al, uygula.
4. `npx remotion render <id> out/<ad>.mp4` ile dışa aktar.
5. İyi çalışan ayarları `marka.md`ye not et.

**Kontrol:** Teslimden önce 3-4 kareyi `npx remotion still` ile çıkarıp bak: taşan yazı, yanlış Türkçe karakter, altyazı-efekt çakışması olmamalı. İsim ve rakamları kullanıcıya teyit ettir.

---
Hazırlayan: Move to Social — movetosocial.com.tr · Instagram: @movetosocialtr
