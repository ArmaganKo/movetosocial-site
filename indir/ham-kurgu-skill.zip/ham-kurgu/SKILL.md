---
name: ham-kurgu
description: "Claude videomu nasıl kurguladı?" formatı: üstte kurgulu, altta ham video; videoda söylenen komutlar o saniyede ekranda gerçekleşir. Remotion.
---

# Ham Kurgu — "Videomu nasıl kurguladı?" formatı

Kişi videoda kurgu komutlarını sesli söyler ("ismimi büyük yaz", "siyah-beyaz yap", "yok, geri al"). Bu skill o komutları bulur ve **söylendiği saniyede** ekranda uygular. Ham ve kurgulu hâl alt alta gösterilir.

## Yerleşim (1080x1920)
- En üstte sabit başlık (2 satır): kalın büyük harf "<KİM> VİDEOMU" + italik serif "nasıl kurguladı?". Başlık kullanıcıdan alınır.
- Üst kart (kurgulu video) ve alt kart (ham video, "HAM VİDEO" etiketi), 16:9'a yakın, yuvarlak köşeli, ince gölgeli, açık krem zemin üstünde. Kartlar arasında 24 px boşluk.
- Üst kartın altında komut kutusu: konuşmadaki komut harf harf yazılır, gönder tuşu yanar.

## Akış
1. Dökümden komut cümlelerini bul (fiil kipleri: yaz, koy, göster, böl, yap, değiştir, sar, geri al). Komut listesini zaman damgalarıyla tablo hâlinde kullanıcıya göster, onaylat.
2. Her komutu bir efekt bileşenine eşle:
   - "ismimi büyük yaz" → arkada dev isim (bkz. text-behind)
   - "... ikonları koy" → konuşanın etrafında beliren ikon kartları
   - "ekranı ikiye böl, solda laptop" → kurgulu video sağa kayar, sol yarıda laptop çerçevesinde ekran görüntüsü
   - "siyah-beyaz yap" → `filter: grayscale(1)`; "geri al" → önceki duruma 8 karede dönüş
   - "renkleri ... yap" → renk paleti kartları + ton değişimi (CSS filter / LUT)
   - "yazılar büyük olsun" → altyazı boyutu artar
   - "3 kapak hazırla" → 3 kapak yelpaze gibi açılır, seçilen öne gelir
   - "müziği değiştir" → müzik kartı yeni parçaya geçer, müzik değişir
   - "başa sar" → "◀◀ GERİ SAR" yazısı + hızlı geri sarma görüntüsü + sayaç
3. Ham alt kart hep sade kalır; sadece üst kart değişir.
4. Sonda: "Claude'a ne istediğimi anlattım" yazısı + yapılan komutların tiklenen listesi.
5. Kapanış: yorum CTA'sı (kelime kullanıcıdan) + hesap adı.

## Çekim notu (kullanıcıya hatırlat)
Komutlar arasında 4-6 sn bırakılsın. "Ekranı ikiye böl" anında kişi hafifçe kenara kaysın.

## Ortak teknik kurallar

**Altyapı:** Remotion projesi (React ile video). Proje yoksa kullanıcıya `npx create-video@latest --yes --blank reels` ile oluşturmayı ve `npx remotion skills add` ile Remotion'ın resmi skill'lerini kurmayı öner. Remotion API'sinde emin olmadığın her şey için Remotion'ın resmi skill'ine ya da belgelerine bak; tahminle API yazma.

**Video ayarları:** 1080x1920, 30 fps, dikey. Ham videoyu `public/` klasörüne koy, `<OffthreadVideo src={staticFile(...)}/>` ile kullan. Süreyi ham videonun süresinden hesapla (`parseMedia` ya da ffprobe).

**Marka:** Proje kökünde `marka.md` varsa oku (renkler, yazı tipi, logo dosyası, hesap adı, kapanış cümlesi). Yoksa işe başlamadan kullanıcıya bu 5 bilgiyi bir kerede sor ve cevapları `marka.md` olarak kaydet. Sonraki videolarda tekrar sorma.

**Döküm:** Altyazı ve zamanlama için konuşmayı kelime kelime zamanlı yazıya dök (ör. `@remotion/install-whisper-cpp` ile whisper.cpp, dil: Türkçe). Dökümü `public/dokum.json` olarak kaydet. Türkçe karakterleri (ç, ğ, ı, İ, ö, ş, ü) kontrol et; büyük harfe çevirirken `toLocaleUpperCase('tr-TR')` kullan.

**Güvenli alan (Instagram Reels):** Yazı ve kartları kenarlardan en az 60 px içeride tut; üstte 220 px, altta 420 px, sağda 140 px boşluk bırak. Hiçbir yazı ekrandan taşmamalı; uzun başlıkta yazı boyutunu küçült ya da satıra böl.

**Animasyon:** `spring()` ve `interpolate()` kullan, `extrapolateRight: 'clamp'` ekle. Giriş 8-12 kare, çıkış 6-8 kare. Aynı anda en fazla bir büyük animasyon.

**Ses:** Müzik dosyası kullanıcıdan gelmeli ya da kullanım hakkı olan bir kütüphaneden seçilmeli. Konuşma varken müzik seviyesi 0.08-0.15.

**Akış:**
1. Planı 5-8 maddeyle yaz (hangi saniyede ne olacak), kullanıcı onaylasın.
2. Kodu yaz, `npx remotion studio` ile önizleme öner.
3. Düzeltmeleri düz Türkçe al, uygula.
4. `npx remotion render <id> out/<ad>.mp4` ile dışa aktar.
5. İyi çalışan ayarları `marka.md`ye not et.

**Kontrol:** Teslimden önce 3-4 kareyi `npx remotion still` ile çıkarıp bak: taşan yazı, yanlış Türkçe karakter, altyazı-efekt çakışması olmamalı. İsim ve rakamları kullanıcıya teyit ettir.

---
Hazırlayan: Move to Social — movetosocial.com.tr · Instagram: @movetosocialtr
